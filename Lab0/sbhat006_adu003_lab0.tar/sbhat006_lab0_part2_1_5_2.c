/* Partner 1 Souradeep Bhattacharya & E-mail: sbhat006@ucr.edu
* Partner 2 Annie Du & E-mail: adu003@ucr.edu
* Lab Section: B21
* Assignment: Lab 0 Exercise 2
* Exercise Description: Participation exercise 1.5.2
*
* I acknowledge all content contained herein, excluding template or example
* code, is my own original work.
*/
#include "RIMS.h"
int main() {
   while(1) {
      B0 = A0 && A1;
      printf("B = %d\r\n", B);
   }
   return 0;
}